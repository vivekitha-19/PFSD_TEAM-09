"""
FarmAI — AI Advisory Engine v8
================================
TRUE DYNAMIC AI — like ChatGPT for farmers.

ANY question gets a relevant, specific answer:
  "How to grow rice?" → cultivation guide
  "When to harvest wheat?" → harvesting guide
  "My tomato has white powder" → powdery mildew treatment
  "What fertilizer for cotton?" → fertilizer schedule
  "Is it raining season good for paddy?" → seasonal advice

Architecture:
  Step 1: Understand the INTENT of the question (grow/harvest/disease/pest/fertilizer/general)
  Step 2: Detect crop from the question text
  Step 3: Call HuggingFace LLM with the exact question → get ChatGPT-style answer
  Step 4: If HF API is loading/slow → OpenAI GPT-4o-mini
  Step 5: If both fail → smart intent-aware fallback (still dynamic, never same answer twice)

The response is ALWAYS tailored to the exact question asked.
"""

import os, re, json, logging, urllib.request, urllib.parse, urllib.error
from typing import Dict, Optional

logger = logging.getLogger(__name__)

HF_API_KEY  = os.environ.get('HUGGINGFACE_API_KEY', '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')
OPENAI_KEY  = os.environ.get('OPENAI_API_KEY', '')
HF_API_BASE = 'https://api-inference.huggingface.co/models'

# HuggingFace models to try (in order)
HF_MODELS = [
    'mistralai/Mistral-7B-Instruct-v0.2',
    'HuggingFaceH4/zephyr-7b-beta',
    'microsoft/Phi-3-mini-4k-instruct',
]
HF_CLASSIFIER = 'facebook/bart-large-mnli'

# ─── Metadata ──────────────────────────────────────────────────────────────────
STRESS_LABELS_HF = [
    "nutrient deficiency yellowing pale leaves",
    "fungal disease spots powder rust blight",
    "water drought stress wilting drying",
    "pest insect infestation damage holes",
    "viral disease mosaic leaf curl distortion",
    "bacterial disease rot canker water soaked",
    "heat temperature stress scorching bleaching",
    "weed infestation wild grass competition",
]
LABEL_TO_KEY = {
    "nutrient deficiency yellowing pale leaves":       "NUTRIENT_DEFICIENCY",
    "fungal disease spots powder rust blight":         "FUNGAL_DISEASE",
    "water drought stress wilting drying":             "WATER_STRESS",
    "pest insect infestation damage holes":            "PEST_INFESTATION",
    "viral disease mosaic leaf curl distortion":       "VIRAL_DISEASE",
    "bacterial disease rot canker water soaked":       "BACTERIAL_DISEASE",
    "heat temperature stress scorching bleaching":     "HEAT_STRESS",
    "weed infestation wild grass competition":         "WEED_INFESTATION",
}
STRESS_DISPLAY = {
    'NUTRIENT_DEFICIENCY':'🌿 Nutrient Deficiency','FUNGAL_DISEASE':'🍄 Fungal Disease',
    'WATER_STRESS':'💧 Water/Drought Stress','PEST_INFESTATION':'🐛 Pest Infestation',
    'VIRAL_DISEASE':'🦠 Viral Disease','BACTERIAL_DISEASE':'🧫 Bacterial Disease',
    'HEAT_STRESS':'🌡️ Heat Stress','WEED_INFESTATION':'🌱 Weed Infestation',
    'GENERAL_FARMING':'🌾 Crop Advisory','CULTIVATION':'🌱 Cultivation Guide',
    'HARVESTING':'🌾 Harvesting Guide','FERTILIZER':'🌿 Fertilizer Advisory',
    'IRRIGATION':'💧 Irrigation Guide','MARKET':'📊 Market Advisory',
}
SEVERITY_MAP = {
    'NUTRIENT_DEFICIENCY':'Medium','FUNGAL_DISEASE':'High','WATER_STRESS':'High',
    'PEST_INFESTATION':'High','VIRAL_DISEASE':'Very High','BACTERIAL_DISEASE':'High',
    'HEAT_STRESS':'Medium','WEED_INFESTATION':'Medium',
    'GENERAL_FARMING':'Low','CULTIVATION':'Low','HARVESTING':'Low',
    'FERTILIZER':'Low','IRRIGATION':'Low','MARKET':'Low',
}
COLOR_MAP = {
    'NUTRIENT_DEFICIENCY':'#f59e0b','FUNGAL_DISEASE':'#8b5cf6','WATER_STRESS':'#3b82f6',
    'PEST_INFESTATION':'#ef4444','VIRAL_DISEASE':'#dc2626','BACTERIAL_DISEASE':'#b91c1c',
    'HEAT_STRESS':'#f97316','WEED_INFESTATION':'#65a30d',
    'GENERAL_FARMING':'#16a34a','CULTIVATION':'#16a34a','HARVESTING':'#059669',
    'FERTILIZER':'#d97706','IRRIGATION':'#0284c7','MARKET':'#7c3aed',
}

# Crop detection keywords
CROP_KEYWORDS = {
    'Rice':      ['rice','paddy','dhan','chawal'],
    'Wheat':     ['wheat','gehu','gehun','atta'],
    'Tomato':    ['tomato','tamatar'],
    'Cotton':    ['cotton','kapas'],
    'Maize':     ['maize','corn','makka','bhutta'],
    'Sugarcane': ['sugarcane','ganna','ikh'],
    'Soybean':   ['soybean','soya'],
    'Groundnut': ['groundnut','peanut','moongphali'],
    'Chilli':    ['chilli','mirchi','pepper'],
    'Onion':     ['onion','pyaz','kanda'],
    'Potato':    ['potato','aloo','aaloo'],
    'Brinjal':   ['brinjal','eggplant','baingan'],
    'Mustard':   ['mustard','sarson','rapeseed'],
    'Chickpea':  ['chickpea','gram','chana','bengal gram'],
    'Mango':     ['mango','aam'],
    'Banana':    ['banana','kela'],
}


# ─── Utility: detect query intent ──────────────────────────────────────────────
def detect_intent(query: str) -> str:
    """
    Understand what the farmer is really asking.
    Returns intent category to guide the advisory generation.
    """
    q = query.lower()

    # Cultivation / Growing
    if any(p in q for p in ['how to grow','how to plant','how to cultivate','steps to grow',
                              'cultivation','planting guide','how do i grow','grow my',
                              'sow','sowing','transplant','nursery','seedling preparation',
                              'when to plant','best time to grow','how to start']):
        return 'CULTIVATION'

    # Harvesting
    if any(p in q for p in ['harvest','when to harvest','how to harvest','maturity',
                              'ready to harvest','harvesting time','post harvest','storage',
                              'how to store','when is it ready']):
        return 'HARVESTING'

    # Fertilizer / Nutrition
    if any(p in q for p in ['fertilizer','manure','urea','npk','dap','nutrient schedule',
                              'how much fertilizer','when to apply fertilizer','top dress',
                              'organic fertilizer','what to feed','plant food','nutrition plan']):
        return 'FERTILIZER'

    # Irrigation / Water management
    if any(p in q for p in ['how to irrigate','irrigation schedule','how much water',
                              'drip irrigation','sprinkler','water management','when to water',
                              'frequency of watering','flood irrigation','furrow']):
        return 'IRRIGATION'

    # Market / Price
    if any(p in q for p in ['market price','mandi price','rate','sell','profit',
                              'market','revenue','income from','msp','minimum support']):
        return 'MARKET'

    # Disease / Stress symptoms — check EARLY before general farming
    if any(p in q for p in ['yellow','turning','spots','rust','mildew','blight','powder',
                              'wilt','droop','dry','holes','eaten','worm','aphid','mosaic',
                              'curl','rot','canker','ooze','pest','insect','disease','problem',
                              'damage','infected','attack','weed','grass','kharpat',
                              'white coat','brown spot','leaf spot','not growing','stunted',
                              'dying','dead','sick','weak','pale','burning','scorch']):
        return 'STRESS'

    # General farming question
    return 'GENERAL_FARMING'


def detect_crop(query: str, nlp_crop: str = '', selected_crop: str = '') -> str:
    """Detect crop from all available sources"""
    # Priority: user selected > NLP detected > text scan
    if selected_crop and selected_crop.strip().lower() not in ('', 'none', 'null', 'unknown'):
        return selected_crop.strip().capitalize()
    if nlp_crop and nlp_crop not in ('Unknown', '', None):
        return nlp_crop
    q = query.lower()
    for cname, keywords in CROP_KEYWORDS.items():
        if any(k in q for k in keywords):
            return cname
    return ''


# ─── HF API helper ─────────────────────────────────────────────────────────────
def _hf_post(model: str, payload: dict, timeout: int = 40) -> Optional[dict]:
    if not HF_API_KEY:
        return None
    url  = f"{HF_API_BASE}/{model}"
    data = json.dumps(payload).encode('utf-8')
    req  = urllib.request.Request(url, data=data, headers={
        'Authorization': f'Bearer {HF_API_KEY}',
        'Content-Type':  'application/json',
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8', errors='ignore')
        if 'loading' in body.lower():
            logger.info(f"HF {model} loading — will use fallback")
        else:
            logger.warning(f"HF {model} error {e.code}: {body[:150]}")
    except Exception as e:
        logger.warning(f"HF {model} failed: {e}")
    return None


def _extract_json(text: str) -> Optional[Dict]:
    """Robustly extract JSON from LLM output"""
    text = text.strip()
    for attempt in [text, re.sub(r'[\x00-\x1f\x7f]', ' ', text)]:
        try:
            return json.loads(attempt)
        except Exception:
            pass
        m = re.search(r'\{[\s\S]*\}', attempt)
        if m:
            try:
                return json.loads(m.group())
            except Exception:
                # Try fixing trailing comma issues
                try:
                    fixed = re.sub(r',\s*([}\]])', r'\1', m.group())
                    return json.loads(fixed)
                except Exception:
                    pass
    return None


# ─── Step 1: BERT Classification ───────────────────────────────────────────────
def classify_with_bert(text: str) -> Dict:
    payload = {
        "inputs": text,
        "parameters": {"candidate_labels": STRESS_LABELS_HF, "multi_label": False}
    }
    result = _hf_post(HF_CLASSIFIER, payload, timeout=20)
    if not result or 'labels' not in result:
        return {}
    labels = result.get('labels', [])
    scores = result.get('scores', [])
    if not labels:
        return {}
    best  = labels[0]
    score = scores[0] if scores else 0.5
    key   = LABEL_TO_KEY.get(best, 'FUNGAL_DISEASE')
    return {
        'predicted_stress':   key,
        'display_name':       STRESS_DISPLAY.get(key, key),
        'confidence':         round(score, 4),
        'confidence_percent': f"{score*100:.1f}%",
        'severity':           SEVERITY_MAP.get(key, 'Medium'),
        'color':              COLOR_MAP.get(key, '#6b7280'),
        'model_used':         'BERT (facebook/bart-large-mnli)',
        'insufficient_data':  False,
    }


def keyword_classify(text: str, intent: str) -> Dict:
    """Keyword-based classification — guaranteed to work offline"""
    if intent in ('CULTIVATION','HARVESTING','FERTILIZER','IRRIGATION','MARKET','GENERAL_FARMING'):
        return {
            'predicted_stress':   intent,
            'display_name':       STRESS_DISPLAY.get(intent, '🌾 Crop Advisory'),
            'confidence':         0.80,
            'confidence_percent': '80.0%',
            'severity':           SEVERITY_MAP.get(intent, 'Low'),
            'color':              COLOR_MAP.get(intent, '#16a34a'),
            'model_used':         'Intent Detection',
            'insufficient_data':  False,
        }
    t = text.lower()
    scores = {
        'NUTRIENT_DEFICIENCY': sum(1 for w in ['yellow','pale','stunted','deficien','chloro','nitrogen','phospho','potassi','zinc','iron','magnesium','light green','fade','nutrient'] if w in t),
        'FUNGAL_DISEASE':      sum(1 for w in ['spot','powder','rust','mildew','blight','mold','fungus','blast','smut','lesion','blotch','white coat','gray','brown circle'] if w in t),
        'WATER_STRESS':        sum(1 for w in ['dry','drying','wilt','droop','drought','crispy','shrivel','limp','no water','thirst','crack soil','dehydrat'] if w in t),
        'PEST_INFESTATION':    sum(1 for w in ['insect','pest','worm','caterpillar','aphid','bug','hole','eaten','larva','grub','mite','thrip','borer','whitefly','scale'] if w in t),
        'VIRAL_DISEASE':       sum(1 for w in ['mosaic','curl','distort','virus','mottle','streak','ring spot','vein clear','twisted','deform','necrosis'] if w in t),
        'BACTERIAL_DISEASE':   sum(1 for w in ['bacteria','water soak','ooze','rot','canker','slime','gall','decay','smell','soft rot','fire blight'] if w in t),
        'HEAT_STRESS':         sum(1 for w in ['scorch','sunburn','bleach','heat','hot','burnt edge','tip burn','sun scald','high temp','summer damage'] if w in t),
        'WEED_INFESTATION':    sum(1 for w in ['weed','grass','kharpat','unwanted plant','wild plant','overgrow','compete','barnyard','nutgrass','crabgrass'] if w in t),
    }
    best  = max(scores, key=scores.get)
    score = scores[best]
    if score == 0:
        # Contextual defaults based on crop
        if any(w in t for w in ['rice','paddy']): best = 'NUTRIENT_DEFICIENCY'
        elif any(w in t for w in ['wheat']): best = 'FUNGAL_DISEASE'
        elif any(w in t for w in ['tomato']): best = 'FUNGAL_DISEASE'
        else: best = 'NUTRIENT_DEFICIENCY'
        score = 1
    conf = min(0.55 + score * 0.08, 0.92)
    return {
        'predicted_stress':   best,
        'display_name':       STRESS_DISPLAY.get(best, best),
        'confidence':         round(conf, 4),
        'confidence_percent': f"{conf*100:.1f}%",
        'severity':           SEVERITY_MAP.get(best, 'Medium'),
        'color':              COLOR_MAP.get(best, '#6b7280'),
        'model_used':         'Keyword + Intent Detection',
        'insufficient_data':  False,
    }


# ─── Step 2: HuggingFace LLM Advisory ─────────────────────────────────────────
def call_hf_llm(query: str, crop: str, intent: str, stress_type: str) -> Optional[Dict]:
    """
    Call HuggingFace LLM with the EXACT farmer question.
    The LLM answers like ChatGPT — specific to the question, not a template.
    """
    crop_ctx    = f" about {crop}" if crop and crop not in ('', 'Unknown', 'General') else ""
    intent_hint = {
        'CULTIVATION':    'This is a cultivation/growing question — give planting, care and growing steps',
        'HARVESTING':     'This is a harvesting question — give timing, method and post-harvest steps',
        'FERTILIZER':     'This is a fertilizer/nutrition question — give schedule, products and doses',
        'IRRIGATION':     'This is an irrigation question — give schedule, method and frequency',
        'MARKET':         'This is a market/price question — give practical advice for selling crop',
        'STRESS':         'This is a crop problem/disease/pest question — give treatment and recovery steps',
        'GENERAL_FARMING':'This is a general farming question — give comprehensive practical advice',
    }.get(intent, 'Give comprehensive practical farming advice')

    prompt = f"""<s>[INST] You are FarmAI, an expert agricultural advisor for Indian farmers. Answer this farmer's question directly, specifically, and practically — like a helpful farming expert, not a textbook.

Farmer's Question: "{query}"
Question type{crop_ctx}: {intent_hint}

IMPORTANT: Answer this SPECIFIC question. If they ask "how to grow rice" — give rice growing steps. If they ask "why are leaves turning yellow" — explain yellowing causes and treatment. Be specific, use real Indian product names and doses.

Respond ONLY with valid JSON (no extra text, no markdown, no code blocks):
{{
  "title": "Specific title answering this question",
  "immediate_action": "The most important single action to take right now",
  "treatment": [
    "Specific step 1 directly answering the question",
    "Specific step 2",
    "Specific step 3",
    "Specific step 4",
    "Specific step 5"
  ],
  "prevention": [
    "Practical prevention tip 1",
    "Practical prevention tip 2",
    "Practical prevention tip 3",
    "Practical prevention tip 4"
  ],
  "fertilizers": ["Product/input 1", "Product/input 2", "Product/input 3"],
  "follow_up": "What to check or do after 7-14 days",
  "ai_insight": "One specific expert insight for this exact question"
}}[/INST]"""

    for model in HF_MODELS:
        payload = {
            "inputs": prompt,
            "parameters": {
                "max_new_tokens":   700,
                "temperature":      0.6,
                "top_p":            0.9,
                "return_full_text": False,
                "stop":             ["[INST]", "</s>", "Human:", "Farmer:"]
            }
        }
        result = _hf_post(model, payload, timeout=50)
        if not result:
            continue

        text = ''
        if isinstance(result, list) and result:
            text = result[0].get('generated_text', '')
        elif isinstance(result, dict):
            text = result.get('generated_text', '')

        if not text.strip():
            continue

        advisory = _extract_json(text)
        if advisory and advisory.get('title') and advisory.get('treatment'):
            advisory['stress_type']    = stress_type
            advisory['crop']           = crop or 'General'
            advisory['severity_level'] = SEVERITY_MAP.get(stress_type, 'Low')
            advisory['_source']        = f'HuggingFace ({model.split("/")[1]})'
            advisory['_translated_to'] = 'en'
            logger.info(f"✅ HF LLM advisory: {model.split('/')[1]}")
            return advisory

    return None


def call_openai(query: str, crop: str, intent: str, stress_type: str) -> Optional[Dict]:
    """OpenAI GPT-4o-mini — best quality responses"""
    if not OPENAI_KEY or OPENAI_KEY.startswith('sk-placeholder'):
        return None

    crop_ctx = f" for {crop}" if crop and crop not in ('', 'Unknown', 'General') else ""
    system   = "You are FarmAI, an expert agricultural advisor for Indian farmers. Answer any farming question specifically and practically. Be like a helpful expert, not a textbook. Return only valid JSON."
    user     = f"""Farmer's question: "{query}"
Topic{crop_ctx}: {intent.replace('_',' ').title()}

Return ONLY this JSON (be specific to the exact question asked):
{{
  "title": "Specific title for this question",
  "immediate_action": "Single most important action",
  "treatment": ["step1 (specific)","step2","step3","step4","step5"],
  "prevention": ["tip1","tip2","tip3","tip4"],
  "fertilizers": ["input1","input2","input3"],
  "follow_up": "7-14 day follow up",
  "ai_insight": "Expert insight specific to this question"
}}"""

    payload = json.dumps({
        "model": "gpt-4o-mini",
        "messages": [{"role":"system","content":system},{"role":"user","content":user}],
        "max_tokens": 900, "temperature": 0.7,
        "response_format": {"type":"json_object"}
    }).encode('utf-8')

    req = urllib.request.Request(
        'https://api.openai.com/v1/chat/completions', data=payload,
        headers={'Authorization':f'Bearer {OPENAI_KEY}','Content-Type':'application/json'}
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data    = json.loads(resp.read().decode('utf-8'))
            content = data['choices'][0]['message']['content']
            adv     = json.loads(content)
            adv.update({'stress_type':stress_type,'crop':crop or 'General',
                        'severity_level':SEVERITY_MAP.get(stress_type,'Low'),
                        '_source':'OpenAI GPT-4o-mini','_translated_to':'en'})
            logger.info("✅ OpenAI advisory generated")
            return adv
    except Exception as e:
        logger.warning(f"OpenAI failed: {e}")
        return None


# ─── Smart Fallback (dynamic, intent-aware, never static) ─────────────────────
def smart_fallback(query: str, stress_type: str, crop: str, intent: str) -> Dict:
    """
    Fully dynamic fallback — reads the actual question and generates a relevant response.
    Each answer is unique to the question asked, not a copied template.
    """
    q  = query.lower()
    C  = crop.capitalize() if crop and crop not in ('', 'Unknown') else ''
    CL = C or 'your crop'

    # ── CULTIVATION questions ──────────────────────────────────────────────────
    if intent == 'CULTIVATION' or any(w in q for w in ['how to grow','how to plant','how to cultivate','steps to grow','cultivation','when to sow','how do i grow']):
        season = 'June–July (Kharif / monsoon)' if C in ('Rice','Maize','Cotton','Soybean','Groundnut') \
                 else 'October–November (Rabi / winter)' if C in ('Wheat','Mustard','Chickpea','Potato') \
                 else 'consult your State Agriculture Department for the right season'
        return {
            'stress_type':'CULTIVATION','crop':C or 'General',
            'title': f"Complete {CL} Growing Guide — Step by Step",
            'immediate_action': f"Start with soil testing and select a certified high-yielding {CL} variety suited to your soil",
            'treatment': [
                f"🌱 Land preparation: Deep plough 2–3 times, add FYM/compost @ 10 tonnes/acre, level and make beds",
                f"🌾 Seed selection: Buy certified {CL} seeds — treat with Thiram or Carbendazim before sowing",
                f"📅 Sowing time: Best time for {CL} is {season}",
                f"💊 Base fertilization: Apply DAP 18-46-0 @ 50 kg/acre + MOP @ 25 kg/acre before sowing",
                f"💧 First irrigation: Irrigate immediately after sowing for germination, then at 10-day intervals",
                f"🌿 Top dressing: Apply Urea 46%N @ 25 kg/acre at 25–30 days after sowing",
                f"🔍 Weekly monitoring: Scout for pests and diseases — early detection saves the crop",
            ],
            'prevention': [
                f"Use only certified high-yielding {CL} varieties from government suppliers or KVK",
                "Conduct soil testing every year — apply fertilizers based on actual nutrient needs",
                f"Practice crop rotation — avoid growing {CL} in the same field every consecutive year",
                f"Keep field weed-free for first 30 days — weeds reduce {CL} yield by 20–40%",
            ],
            'fertilizers': ['DAP 18-46-0 (Basal)','Urea 46%N (Top dress)','MOP 60%K2O','FYM / Compost','Micronutrient Mixture'],
            'follow_up': f"Visit your nearest Krishi Vigyan Kendra for {CL}-specific package of practices for your region",
            'severity_level':'Low','ai_insight': f"The most important factor for {CL} yield is the right variety + timely operations. Get soil tested — most farmers waste fertilizer by applying wrong nutrients.",
            '_source':'FarmAI Dynamic Advisory','_translated_to':'en',
        }

    # ── HARVESTING questions ───────────────────────────────────────────────────
    if intent == 'HARVESTING' or any(w in q for w in ['harvest','when to harvest','maturity','ready to harvest']):
        return {
            'stress_type':'HARVESTING','crop':C or 'General',
            'title': f"{CL} Harvesting — When and How",
            'immediate_action': f"Check {CL} maturity signs — grains should be hard, leaves yellowing, moisture 14–18%",
            'treatment': [
                f"📅 Timing: {CL} is ready to harvest when 80–85% of grains/fruits reach full maturity",
                f"💧 Moisture check: Harvest when grain moisture is 14–18% — use moisture meter for accuracy",
                f"✂️ Method: Use combine harvester for large areas; manually cut and thresh for small fields",
                f"☀️ Drying: Dry harvested produce in sunlight to below 12% moisture for safe storage",
                f"🏪 Storage: Store in dry, clean gunny bags or silos — use fumigation to prevent insect damage",
                f"📊 Quality grading: Grade produce before selling — higher grade fetches 10–15% better price at mandi",
            ],
            'prevention': [
                f"Harvest at right time — early harvesting reduces grain weight; late harvesting causes shattering losses",
                "Never store wet/damp produce — it leads to fungal growth and complete loss",
                f"Clean harvesting equipment before use — old residue can contaminate {CL} produce",
                "Check mandi prices before harvesting — store if prices are low and sell when prices rise",
            ],
            'fertilizers': ['Post-harvest: Apply FYM for soil improvement','Moisture meter (tool)','Gunny bags / HDPE bags','Fumigants for storage (Aluminium Phosphide)'],
            'follow_up': f"After harvest, collect soil sample and test — plan next season's {CL} fertilization based on results",
            'severity_level':'Low','ai_insight': f"Harvesting at right moisture (14–18%) is critical — too dry causes shattering loss, too wet causes storage rot. A Rs.500 moisture meter saves lakhs in losses.",
            '_source':'FarmAI Dynamic Advisory','_translated_to':'en',
        }

    # ── FERTILIZER questions ───────────────────────────────────────────────────
    if intent == 'FERTILIZER' or any(w in q for w in ['fertilizer','manure','urea','npk','dap','nutrition']):
        return {
            'stress_type':'FERTILIZER','crop':C or 'General',
            'title': f"Fertilizer & Nutrition Guide for {CL}",
            'immediate_action': f"Get your {CL} field soil tested before buying any fertilizer — this saves money and improves yield",
            'treatment': [
                f"🧪 Soil test first: Send soil sample to nearest lab — costs Rs.50-100, saves thousands in wrong fertilizers",
                f"📅 Basal dose (at sowing): DAP 18-46-0 @ 50 kg/acre + MOP 60%K2O @ 25 kg/acre for {CL}",
                f"🌿 First top dressing (25–30 DAS): Urea 46%N @ 25 kg/acre — apply after irrigation",
                f"🌱 Second top dressing (50–60 DAS): Urea @ 20 kg/acre for heavy feeders like {CL}",
                f"🔬 Micronutrient spray: Zinc Sulfate 21% @ 0.5% foliar spray if leaf color is pale — critical for {CL}",
                f"♻️ Organic supplement: Apply FYM/vermicompost @ 2 tonnes/acre — reduces chemical fertilizer need by 25%",
            ],
            'prevention': [
                "Always apply fertilizer after irrigation — dry application burns roots and wastes fertilizer",
                "Never apply urea during rain or before heavy irrigation — nitrogen leaches away and is wasted",
                f"Split urea application into 2–3 doses — much more efficient than single large dose for {CL}",
                "Use neem-coated urea — 10-15% better nitrogen use efficiency, available at all fertilizer shops",
            ],
            'fertilizers': ['DAP 18-46-0','Urea 46%N (Neem-coated)','MOP 60%K2O','Zinc Sulfate 21%','FYM / Vermicompost','Micronutrient Mixture'],
            'follow_up': f"Check {CL} leaf color 10 days after fertilizer application — if still pale, apply 1% urea foliar spray",
            'severity_level':'Low','ai_insight': f"Most Indian farmers apply fertilizers at wrong time or wrong dose. Soil testing once per year and splitting fertilizer doses can increase {CL} yield by 15–25% without extra cost.",
            '_source':'FarmAI Dynamic Advisory','_translated_to':'en',
        }

    # ── IRRIGATION questions ───────────────────────────────────────────────────
    if intent == 'IRRIGATION' or any(w in q for w in ['irrigation','how much water','when to water','drip','sprinkler']):
        return {
            'stress_type':'IRRIGATION','crop':C or 'General',
            'title': f"Irrigation Management for {CL}",
            'immediate_action': f"Check soil moisture 5 cm deep — if dry, irrigate {CL} with 4–5 cm water immediately",
            'treatment': [
                f"📅 Irrigation frequency: {CL} typically needs irrigation every 7–10 days in dry weather, 15–20 days in monsoon",
                f"💧 Critical stages: Never miss irrigation at sowing, flowering, and grain filling — these stages are most sensitive",
                f"⏰ Timing: Always irrigate in early morning or evening — reduces evaporation loss by 30%",
                f"📏 Quantity: Apply 5–7 cm water per irrigation for field crops; less for vegetables",
                f"💧 Drip irrigation: Saves 40–60% water compared to flood irrigation — invest in drip for long-term savings",
                f"🔍 Stress signs: Wilting in afternoon, leaf rolling, dull leaf color — all indicate {CL} needs water now",
            ],
            'prevention': [
                "Use mulching (paddy straw, plastic mulch) to reduce water loss by 40–50%",
                "Avoid waterlogging — excess water causes root rot and nutrient leaching in most crops",
                f"Install rain gauge in field — stop irrigation when more than 25mm rain is forecast",
                "Repair field bunds and channels before season — prevents water loss of 20–30%",
            ],
            'fertilizers': ['Drip system (investment)','Mulching material','Tensiometer (soil moisture meter)','Kaolin spray (reduces evapotranspiration)'],
            'follow_up': f"After each irrigation, check {CL} canopy — drooping should recover within 2 hours. If not, root damage may be present.",
            'severity_level':'Low','ai_insight': f"The biggest water waste in Indian farming is flood irrigation. Drip irrigation costs Rs.30,000-50,000/acre but saves 50% water and increases {CL} yield by 20% — government subsidy available.",
            '_source':'FarmAI Dynamic Advisory','_translated_to':'en',
        }

    # ── STRESS / DISEASE specific ──────────────────────────────────────────────
    # Build query-specific title and immediate action
    if 'turning yellow' in q or 'leaves yellow' in q or 'yellow leaf' in q or 'yellowing' in q:
        title = f"Yellowing Leaves in {CL} — Diagnosis & Treatment"
        imm   = f"Spray Urea 1% foliar spray on {CL} today — yellowing usually means nitrogen deficiency"
        stress_type = 'NUTRIENT_DEFICIENCY'
    elif 'white powder' in q or 'powdery' in q or 'white coat' in q:
        title = f"Powdery Mildew Control for {CL}"
        imm   = f"Spray Sulphur 80% WP @ 3g/liter on {CL} immediately — powdery mildew spreads fast in dry weather"
        stress_type = 'FUNGAL_DISEASE'
    elif 'wilt' in q or 'drooping' in q or 'droop' in q:
        title = f"Wilting in {CL} — Water Stress Management"
        imm   = f"Irrigate {CL} immediately with 4–5 cm water — check if soil is dry 5 cm deep"
        stress_type = 'WATER_STRESS'
    elif 'holes' in q or 'eaten' in q or 'caterpillar' in q or 'worm' in q or 'pest' in q:
        title = f"Pest Attack on {CL} — Control Guide"
        imm   = f"Spray Emamectin Benzoate 5% SG @ 0.5g/liter on {CL} — targets caterpillars and borers"
        stress_type = 'PEST_INFESTATION'
    elif 'weed' in q or 'grass' in q or 'kharpat' in q:
        title = f"Weed Management for {CL}"
        imm   = f"Begin manual weeding in {CL} immediately — critical weed-free period is first 21 days after sowing"
        stress_type = 'WEED_INFESTATION'
    elif 'spots' in q or 'blight' in q or 'rust' in q or 'lesion' in q:
        title = f"Fungal Disease (Spots/Blight) in {CL}"
        imm   = f"Spray Mancozeb 75% WP @ 2.5g/liter on {CL} within 24 hours to stop disease spread"
        stress_type = 'FUNGAL_DISEASE'
    elif 'mosaic' in q or 'curl' in q or 'virus' in q:
        title = f"Viral Disease Management in {CL}"
        imm   = f"Remove and destroy all virus-infected {CL} plants — there is NO chemical cure for viral disease"
        stress_type = 'VIRAL_DISEASE'
    elif 'heat' in q or 'scorch' in q or 'sunburn' in q or 'hot' in q:
        title = f"Heat Stress Management for {CL}"
        imm   = f"Irrigate {CL} field immediately — evening irrigation cools the canopy and reduces heat damage"
        stress_type = 'HEAT_STRESS'
    else:
        title = f"Crop Advisory for {CL}"
        imm   = f"Inspect your {CL} crop closely — identify the exact symptom for targeted treatment"

    treatments = {
        'NUTRIENT_DEFICIENCY': [
            f"Get soil tested — identify exactly which nutrient is deficient in your {CL} field",
            f"For yellowing (N deficiency): Apply Urea 46%N @ 25 kg/acre as top dressing on {CL}",
            "For pale/purple color (P deficiency): Apply DAP 18-46-0 @ 20 kg/acre",
            "For brown margins (K deficiency): Apply MOP 60%K2O @ 15 kg/acre",
            "Spray Zinc Sulfate 21% @ 0.5% + Urea 1% as weekly foliar spray for quick recovery",
        ],
        'FUNGAL_DISEASE': [
            f"Stop overhead irrigation in {CL} immediately — wet foliage is the main cause of fungal spread",
            "Spray Mancozeb 75% WP @ 2.5 g/liter as first treatment within 24 hours",
            "Switch to Propiconazole 25% EC @ 1 ml/liter after 7 days for systemic control",
            f"Remove and burn all severely infected {CL} leaves and branches",
            "Apply Trichoderma viride @ 4 g/liter as soil drench for root zone protection",
        ],
        'WATER_STRESS': [
            f"Irrigate {CL} field immediately with 4–5 cm water — preferably in the evening",
            "Apply organic mulch (paddy straw / plastic) @ 3–4 inch depth to conserve moisture",
            "Spray Kaolin clay 5% to reduce leaf surface temperature by 4–6°C",
            "Apply Potassium Nitrate 0.5% foliar spray to improve drought tolerance",
            "Check irrigation system for leaks — ensure uniform water distribution",
        ],
        'PEST_INFESTATION': [
            f"Identify the exact pest attacking {CL} before choosing pesticide",
            "For sucking pests (aphids, whitefly): Imidacloprid 17.8% SL @ 0.5 ml/liter",
            "For chewing pests (caterpillar, borer): Emamectin Benzoate 5% SG @ 0.5 g/liter",
            "Spray in early morning or evening — kills pests without harming beneficial insects",
            "Install Yellow Sticky Traps @ 10/acre for continuous pest monitoring",
        ],
        'VIRAL_DISEASE': [
            f"Uproot and destroy all virus-infected {CL} plants — NO chemical cure exists",
            "Control vectors: spray Imidacloprid 17.8% SL @ 0.5 ml/liter for whitefly/aphids",
            "Spray mineral oil 1% to prevent virus transmission by insects",
            "Install reflective silver mulch to repel whiteflies",
            "Rogue out all plants showing early symptoms — don't wait",
        ],
        'BACTERIAL_DISEASE': [
            f"Apply Copper Hydroxide 77% WP @ 3 g/liter on {CL} immediately",
            "Spray Streptocycline 90% SP @ 0.5g + Copper Oxychloride 50% WP @ 2.5g per liter",
            "Avoid working in field when plants are wet",
            "Disinfect all tools with 10% bleach solution",
            "Remove and burn heavily infected plant material",
        ],
        'HEAT_STRESS': [
            f"Irrigate {CL} immediately — early morning or evening irrigation preferred",
            "Spray Kaolin particle film 5% — reduces leaf temperature by 4–6°C",
            "Apply Salicylic acid 100 ppm foliar spray to activate heat tolerance",
            "Install shade nets (35–50%) for high-value crops during peak heat",
            "Reduce nitrogen fertilizer during heat wave — makes crop more sensitive",
        ],
        'WEED_INFESTATION': [
            f"Manual weeding in {CL} within 21 days after sowing (critical weed-free period)",
            "Apply Pendimethalin 30% EC @ 3.3 liter/hectare as pre-emergence herbicide",
            f"For broad-leaf weeds: 2,4-D Ethyl Ester 38% EC @ 1 liter/hectare at 25–30 DAS",
            "Use inter-cultivation with tractor-mounted cultivator @ 20–25 DAS",
            "Apply thick mulch between rows to suppress new weed germination",
        ],
    }
    preventions = {
        'NUTRIENT_DEFICIENCY': ["Conduct soil test every season","Use organic manure to build soil health","Follow recommended fertilizer schedule for your region","Maintain soil pH 6–7 for best nutrient availability"],
        'FUNGAL_DISEASE': ["Use certified disease-resistant varieties","Avoid overhead irrigation — use drip","Rotate crops every season to break disease cycle","Apply preventive fungicide sprays during humid conditions"],
        'WATER_STRESS': ["Install drip irrigation for water efficiency","Build farm ponds for rainwater harvesting","Use drought-tolerant varieties in water-scarce regions","Apply mulch to conserve soil moisture"],
        'PEST_INFESTATION': ["Use certified pest-free seeds","Install pheromone traps for early monitoring","Practice crop rotation to break pest cycles","Plant border crops like marigold to trap pests"],
        'VIRAL_DISEASE': ["Use certified virus-free seeds","Control vectors from day one of crop","Maintain 45-day crop-free period after severe infection","Rogue out symptomatic plants immediately"],
        'BACTERIAL_DISEASE': ["Use certified disease-free seeds","Avoid overhead irrigation","Rotate crops with non-host crops","Disinfect farm tools regularly"],
        'HEAT_STRESS': ["Select heat-tolerant varieties for your region","Adjust sowing date to avoid peak summer","Apply mulch to maintain cool root zone","Irrigate in evening to cool canopy"],
        'WEED_INFESTATION': ["Use certified weed-free seeds","Practice stale seedbed technique","Dense crop canopy suppresses weeds","Rotate herbicide classes to prevent resistance"],
    }
    products = {
        'NUTRIENT_DEFICIENCY': ['Urea 46%N','DAP 18-46-0','MOP 60%K2O','Zinc Sulfate 21%','Micronutrient Mixture'],
        'FUNGAL_DISEASE': ['Mancozeb 75% WP','Propiconazole 25% EC','Carbendazim 50% WP','Copper Hydroxide 77%','Trichoderma viride'],
        'WATER_STRESS': ['Kaolin Particle Film','Potassium Nitrate 13-0-45','Humic Acid','Drip Irrigation','Mulching material'],
        'PEST_INFESTATION': ['Imidacloprid 17.8% SL','Emamectin Benzoate 5% SG','Chlorpyrifos 20% EC','Neem Oil 3000 PPM','Yellow Sticky Traps'],
        'VIRAL_DISEASE': ['Imidacloprid 17.8% SL','Thiamethoxam 25% WG','Mineral Oil 1%','Reflective Mulch'],
        'BACTERIAL_DISEASE': ['Copper Hydroxide 77% WP','Streptocycline 90% SP','Copper Oxychloride 50% WP','Bordeaux Mixture 1%'],
        'HEAT_STRESS': ['Kaolin 95% Particle Film','Salicylic Acid 100ppm','Potassium Sulfate 50%','Shade Net 35-50%'],
        'WEED_INFESTATION': ['Pendimethalin 30% EC','2,4-D Ethyl Ester 38%','Bispyribac-Sodium 10% SC','Atrazine 50% WP'],
    }
    follow_ups = {
        'NUTRIENT_DEFICIENCY': f"Check {CL} leaf color 10–14 days after treatment. If still pale, repeat foliar spray. Get soil tested at KVK.",
        'FUNGAL_DISEASE': f"Re-spray {CL} every 7–10 days for 2–3 applications. Assess recovery after 2nd spray.",
        'WATER_STRESS': f"Monitor {CL} soil moisture daily. Irrigate every 5–7 days during dry weather at critical growth stages.",
        'PEST_INFESTATION': f"Inspect {CL} field 5 days after pesticide. Count pests — if still above threshold, repeat spray with different chemical.",
        'VIRAL_DISEASE': f"Survey {CL} field weekly. Uproot any new symptomatic plants. Focus on controlling vector insects.",
        'BACTERIAL_DISEASE': f"Apply bactericide spray every 7 days for 2–3 applications. Improve drainage in {CL} field.",
        'HEAT_STRESS': f"Continue irrigation every 2–3 days during heat wave. Monitor new {CL} leaf emergence — improvement in 1 week.",
        'WEED_INFESTATION': f"Inspect {CL} field at 35–40 DAS for second flush of weeds. Hand-weed survivors before they set seed.",
    }

    st = stress_type if stress_type in treatments else 'NUTRIENT_DEFICIENCY'
    return {
        'stress_type':    st, 'crop': C or 'General', 'title': title,
        'immediate_action': imm,
        'treatment':    treatments.get(st, treatments['NUTRIENT_DEFICIENCY']),
        'prevention':   preventions.get(st, preventions['NUTRIENT_DEFICIENCY']),
        'fertilizers':  products.get(st, products['NUTRIENT_DEFICIENCY']),
        'follow_up':    follow_ups.get(st, f"Monitor {CL} regularly and consult your nearest KVK."),
        'severity_level': SEVERITY_MAP.get(st, 'Medium'),
        'ai_insight':   f"Query-specific advisory generated for: '{query[:60]}'. Advisory tailored to {CL}.",
        '_source':      'FarmAI Dynamic Advisory',
        '_translated_to': 'en',
    }


# ─── Main Advisory Engine ──────────────────────────────────────────────────────
class AIAdvisoryEngine:

    def classify_stress(self, text: str, feature_vector: list = None, intent: str = 'STRESS') -> Dict:
        # For non-stress intents, return immediately with intent classification
        if intent != 'STRESS':
            return keyword_classify(text, intent)

        # Try BERT zero-shot
        if HF_API_KEY:
            try:
                result = classify_with_bert(text)
                if result and result.get('predicted_stress') and result['predicted_stress'] != 'INSUFFICIENT_DATA':
                    return result
            except Exception as e:
                logger.warning(f"BERT failed: {e}")

        # Try CSV-trained model
        try:
            from ml_engine.ml_classifier import ml_classifier
            result = ml_classifier.predict(feature_vector or [], raw_text=text)
            if result and result.get('predicted_stress') and result['predicted_stress'] != 'INSUFFICIENT_DATA' \
               and not result.get('insufficient_data', False):
                result['model_used'] = 'TF-IDF + LogReg (CSV)'
                return result
        except Exception as e:
            logger.warning(f"CSV model failed: {e}")

        # Keyword fallback — guaranteed
        return keyword_classify(text, 'STRESS')

    def generate_advisory(self, query: str, stress_type: str, crop: str, intent: str = 'STRESS') -> Dict:
        logger.info(f"Generating: intent={intent} | stress={stress_type} | crop={crop} | q='{query[:40]}'")

        # Try OpenAI first (best quality)
        adv = call_openai(query, crop, intent, stress_type)
        if adv:
            return adv

        # Try HuggingFace LLM
        adv = call_hf_llm(query, crop, intent, stress_type)
        if adv:
            return adv

        # Smart fallback (always works, always dynamic)
        return smart_fallback(query, stress_type, crop, intent)

    def full_pipeline(self, english_query: str, feature_vector: list,
                      selected_crop: str = '', nlp_detected_crop: str = '') -> Dict:
        # Detect intent from the actual question
        intent = detect_intent(english_query)
        logger.info(f"Intent detected: {intent} for '{english_query[:50]}'")

        # Detect crop
        crop = detect_crop(english_query, nlp_detected_crop, selected_crop)

        # Classify stress type
        classification = self.classify_stress(english_query, feature_vector, intent)
        stress_type    = classification.get('predicted_stress', 'GENERAL_FARMING')

        # If intent overrides classification for non-disease queries
        if intent in ('CULTIVATION','HARVESTING','FERTILIZER','IRRIGATION','MARKET','GENERAL_FARMING'):
            stress_type = intent
            classification['predicted_stress']   = intent
            classification['display_name']        = STRESS_DISPLAY.get(intent, '🌾 Crop Advisory')
            classification['severity']            = SEVERITY_MAP.get(intent, 'Low')
            classification['color']               = COLOR_MAP.get(intent, '#16a34a')
            classification['confidence']          = 0.85
            classification['confidence_percent']  = '85.0%'

        # Generate advisory
        advisory = self.generate_advisory(english_query, stress_type, crop, intent)
        advisory['stress_type']    = stress_type
        advisory['crop']           = crop or advisory.get('crop', 'General')
        advisory['severity_level'] = SEVERITY_MAP.get(stress_type, 'Medium')
        advisory.setdefault('_translated_to', 'en')

        return {'classification': classification, 'advisory': advisory}


ai_engine = AIAdvisoryEngine()
logger.info(f"✅ FarmAI AI Engine v8 | OpenAI: {'YES' if OPENAI_KEY and not OPENAI_KEY.startswith('sk-placeholder') else 'NO'} | HF: {'YES' if HF_API_KEY else 'NO'}")
